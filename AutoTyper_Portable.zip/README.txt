================================================================================
AUTO TYPER - Portable Desktop Edition (No Installation Required)
================================================================================

This portable software can run on any Windows 10 or Windows 11 (64-bit) PC.
All required runtimes and libraries (pynput, pyperclip, tkinter) are bundled 
directly into the executable. Python is NOT required on the target computer.

--------------------------------------------------------------------------------
HOW TO USE:
--------------------------------------------------------------------------------
1. Double-click "AutoTyper.exe" to launch the application.
2. Paste or type your code / text into the editor area.
3. Configure your settings:
   - Code Mode [ON]: Recommended for VS Code, Cursor, PyCharm, LeetCode, etc.
     Prevents double indentation and fixes staircase cascading.
   - Code Mode [OFF]: For Notepad, Word, or plain text web fields.
     Types whatever is in the window verbatim character-by-character.
   - Spaces per Tab: Standard is 4 for Python/C++/Java, 2 for JS/Web.
     (Tip: Use the "Auto-Detect Indent" button to configure this automatically!)
   - Typing Speed: Adjust the slider (40-60 ms is recommended for natural typing).
   - Start Countdown: Number of seconds to give you time to click your target window.
4. Click "START TYPING" (or press F6 / Ctrl+Enter).
5. Switch to your target code editor / window before the countdown finishes.

--------------------------------------------------------------------------------
KEYBOARD SHORTCUTS:
--------------------------------------------------------------------------------
- Start Typing:      F6  or  Ctrl + Enter
- Emergency Stop:    F8  (Works globally even when AutoTyper is unfocused)
- Paste Code:        Ctrl + V  or  the "Paste" toolbar button

--------------------------------------------------------------------------------
FEATURES & OPTIMIZATIONS:
--------------------------------------------------------------------------------
- Smart IDE Indentation: Syncs with IDE auto-indentation to eliminate cascading spaces.
- Autocomplete Dismissal: Taps Esc before Enter to prevent unwanted Copilot/IntelliSense insertions.
- Auto-Detect Indentation: Automatically detects 2-space, 4-space, or tab layouts.
- Humanized Speed Jitter: Adds natural cadence, punctuation pauses, and rhythm.
- Auto-Minimize / Restore: Automatically minimizes to reveal your code editor, then restores on finish.

================================================================================
Generated for: Portable Windows Distribution
Location: E:\Auto-Typer\App\AutoTyper.exe
================================================================================
